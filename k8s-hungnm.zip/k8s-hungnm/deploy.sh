#!/bin/bash
# Nhận từ GitLab CI trigger:
#   $SERVICE    — tên service, vd: f2c-ecommerce
#   $NAMESPACE  — k8s namespace deploy tới
#   $ENV        — dev | stg | prod
#   $IMAGE_REPO — full registry path
#   $IMAGE_TAG  — image tag cần deploy

set -eo pipefail

# ─────────────────────────────────────────────────────────────
# Validate required variables
# ─────────────────────────────────────────────────────────────
REQUIRED_VARS="SERVICE NAMESPACE ENV IMAGE_REPO IMAGE_TAG"
MISSING=""
for VAR in ${REQUIRED_VARS}; do
  if [ -z "${!VAR:-}" ]; then
    MISSING="${MISSING} ${VAR}"
  fi
done
if [ -n "${MISSING}" ]; then
  echo "ERROR: Thiếu biến bắt buộc:${MISSING}"
  exit 1
fi

OVERLAY_PATH="overlays/${SERVICE}/${ENV}"

echo "==> Service:   ${SERVICE}"
echo "==> Namespace: ${NAMESPACE}"
echo "==> Env:       ${ENV}"
echo "==> Image:     ${IMAGE_REPO}:${IMAGE_TAG}"
echo "==> Overlay:   ${OVERLAY_PATH}"

# ─────────────────────────────────────────────────────────────
# Validate overlay path tồn tại
# ─────────────────────────────────────────────────────────────
if [ ! -f "${OVERLAY_PATH}/kustomization.yaml" ]; then
  echo "ERROR: Không tìm thấy ${OVERLAY_PATH}/kustomization.yaml"
  exit 1
fi

# ─────────────────────────────────────────────────────────────
# Tạo namespace nếu chưa có
# ─────────────────────────────────────────────────────────────
kubectl get namespace "${NAMESPACE}" &>/dev/null \
  || kubectl create namespace "${NAMESPACE}"

# ─────────────────────────────────────────────────────────────
# Tạo registry pull secret nếu chưa có
# Dùng CI variables: REGISTRY_URL, REGISTRY_USER, REGISTRY_PASSWORD
# kubectl tự encode base64 — không hardcode credentials
# ─────────────────────────────────────────────────────────────
kubectl get secret registry-secret -n "${NAMESPACE}" &>/dev/null || \
kubectl create secret docker-registry registry-secret \
  --docker-server="${REGISTRY_URL}" \
  --docker-username="${REGISTRY_USER}" \
  --docker-password="${REGISTRY_PASSWORD}" \
  -n "${NAMESPACE}"

# ─────────────────────────────────────────────────────────────
# Build kustomize overlay với image override tạm thời
# Copy toàn bộ repo vào thư mục tạm để giữ relative path đến base
# ─────────────────────────────────────────────────────────────
TMP_ROOT=$(mktemp -d)
cp -r . "${TMP_ROOT}/"

TMP_OVERLAY="${TMP_ROOT}/overlays/${SERVICE}/${ENV}"

# Inject image tag và namespace vào kustomization.yaml trong thư mục tạm
sed -i "s|newTag:.*|newTag: ${IMAGE_TAG}|g" "${TMP_OVERLAY}/kustomization.yaml"
sed -i "s|newName:.*|newName: ${IMAGE_REPO}|g" "${TMP_OVERLAY}/kustomization.yaml"
sed -i "s|namespace: NAMESPACE_PLACEHOLDER|namespace: ${NAMESPACE}|g" "${TMP_OVERLAY}/kustomization.yaml"

echo "==> Kustomize build & apply..."
# Không dùng -n flag — namespace đã được set trong kustomization.yaml
kubectl kustomize "${TMP_OVERLAY}" | kubectl apply -f -

# Dọn dẹp thư mục tạm
rm -rf "${TMP_ROOT}"

# ─────────────────────────────────────────────────────────────
# Force restart để pod load ConfigMap/Secret mới nhất
# kubectl apply không tự restart pod khi chỉ ConfigMap thay đổi
# ─────────────────────────────────────────────────────────────
kubectl rollout restart deployment/"${SERVICE}" -n "${NAMESPACE}"

# ─────────────────────────────────────────────────────────────
# Chờ rollout hoàn tất
# ─────────────────────────────────────────────────────────────
kubectl rollout status deployment/"${SERVICE}" \
  -n "${NAMESPACE}" \
  --timeout=180s

echo "==> Deployed ${SERVICE} → ${NAMESPACE} @ ${IMAGE_REPO}:${IMAGE_TAG}"
